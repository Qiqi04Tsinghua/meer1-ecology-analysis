### Author Shanshan Huang & Dr. Qi Qi
###package and the file
library(dplyr)
library(ggplot2)
#the ecological process of  MAG
icamp_mag <- read.csv("D:/1ASJ/MEER/MAGdataplota/Code_MEER/genomic_correlation/data/mag_icamp_summary.csv",
                      header = T,row.names = 1)
#OGT and MGT of MAG
ogt <- read.table("D:/1ASJ/MEER/MAGdataplota/Code_MEER/genomic_correlation/data/meer_rv2.growthpred.tsv",
                  header = T)
names(ogt)[1] <- "ID"
ogt1 <- ogt [,c(1,2,10)]

merge_data <- left_join(icamp_mag,ogt1,by="ID")
#add the group accroding to DL,HeS,HoS
merge_data$group <- ifelse(merge_data$DL > 0.5, "#984EA2", 
                           ifelse(merge_data$HoS > 0.5, "#377EB8", 
                                  "#E51A1B"))
gc <- read.table("D:/1ASJ/MEER/MAGdataplota/Code_MEER/genomic_correlation/data/pan-prodigal_single.concat.statistic.tsv",
                 header = T)
gc1<-gc[,c(1,2,4)]
### all genomic feature data of MAG
merge_all<- left_join(merge_data,gc1,by="ID")
merge_all <- merge_all %>%
  mutate(gc1 = gc * 100,  # 
         bp = bp_size / 1000000)

merge_all <- merge_all %>%
  mutate(bp = as.numeric(bp),
         gc1 = as.numeric(gc1))

### HoS & genome size
p1<-ggplot(data=merge_all,aes(x=HoS*100,y=bp))+#
  theme_bw()+
  theme(panel.grid = element_blank()) +
  geom_point(aes(colour=color),size=2.5,shape=16,alpha=0.5)+#
  ##geom_point(color="gray",size=2.5,shape=16,alpha=1)+#
  labs(x=paste0("The percentage of HoS (%)"),
       y=paste0("Genome size (Mbp)"))+
  scale_color_identity() + 
  #scale_fill_manual(values = "gray")+
  theme(axis.title.x=element_text(size=13),#
        axis.title.y=element_text(size=13,angle=90),#
        axis.text.y=element_text(size=13,color="black"),#x
        axis.text.x=element_text(size=13,color="black"),
        panel.border = element_rect(linewidth  = 1, color = "black"))+ 
  #geom_vline(xintercept = 50, linetype = "dashed", color = "black",linewidth = 0.5) +
  geom_smooth(method = "lm",level=0.95,color="#377EB8",se=F)+
  scale_x_continuous(limits = c(0, 100), breaks = seq(0, 100, by = 25))
p1
model <- lm(bp ~ HoS, data = merge_all)
summary(model)

ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/genomic_correlation/output/hos-bp.tiff", 
       plot = p1, width = 3.2, height = 3, dpi = 300)

### HeS & genome size
p1<-ggplot(data=merge_all,aes(x=HeS*100,y=bp))+#
  theme_bw()+
  theme(panel.grid = element_blank()) +
  geom_point(aes(colour=color),size=2.5,shape=16,alpha=0.5)+#
  ##geom_point(color="gray",size=2.5,shape=16,alpha=1)+#
  labs(x=paste0("The percentage of HeS (%)"),
       y=paste0("Genome size (Mbp)"))+
  scale_color_identity() + 
  #scale_fill_manual(values = "gray")+
  theme(axis.title.x=element_text(size=13),
        axis.title.y=element_text(size=13,angle=90),
        axis.text.y=element_text(size=13,color="black"),
        axis.text.x=element_text(size=13,color="black"),
        panel.border = element_rect(linewidth  = 1, color = "black"))+ 
  #geom_vline(xintercept = 50, linetype = "dashed", color = "black",linewidth = 0.5) +
  geom_smooth(method = "lm",level=0.95,color="#E51A1B",se=F)+
  scale_x_continuous(limits = c(0, 35), breaks = seq(0, 35, by = 10))
p1
model <- lm(bp ~ HeS, data = merge_all)
summary(model)

ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/genomic_correlation/output/hes-bp.tiff", 
       plot = p1, width = 3.2, height = 3, dpi = 300)

### DL & genome size
p1<-ggplot(data=merge_all,aes(x=DL*100,y=bp))+#
  theme_bw()+
  theme(panel.grid = element_blank()) +
  geom_point(aes(colour=color),size=2.5,shape=16,alpha=0.5)+#
  ##geom_point(color="gray",size=2.5,shape=16,alpha=1)+#
  labs(x=paste0("The percentage of DL (%)"),
       y=paste0("Genome size (Mbp)"))+
  scale_color_identity() + 
  #scale_fill_manual(values = "gray")+
  theme(axis.title.x=element_text(size=13),#
        axis.title.y=element_text(size=13,angle=90),#
        axis.text.y=element_text(size=13,color="black"),#x
        axis.text.x=element_text(size=13,color="black"),
        panel.border = element_rect(linewidth  = 1, color = "black"))+ 
  #geom_vline(xintercept = 50, linetype = "dashed", color = "black",linewidth = 0.5) +
  geom_smooth(method = "lm",level=0.95,color="#984EA2",se=F)+
  scale_x_continuous(limits = c(0, 85), breaks = seq(0, 85, by = 25))
p1
model <- lm(bp ~ DL, data = merge_all)
summary(model)

ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/genomic_correlation/output/DL-bp.tiff", 
       plot = p1, width = 3.2, height = 3, dpi = 300)





