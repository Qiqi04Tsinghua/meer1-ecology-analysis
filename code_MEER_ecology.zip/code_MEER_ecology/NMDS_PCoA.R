#### library packages and load the mag and group
library(vroom)
library(ggplot2)
library(vegan)
library(tidyverse)
library(dplyr)
#### load the MAG and group file
mag<-read.table("D:/1ASJ/MEER/MAGdataplota/Code_MEER/beta_diversity/data/meer_rv2.rpkm.tsv", 
                sep="\t",header = T,row.names=1)#
mag <- t(mag)

group<-read.table("D:/1ASJ/MEER/MAGdataplota/Code_MEER/beta_diversity/data/meta_Sample.txt",
                  sep='\t', header=T,check.names=FALSE )
group$Sample<-gsub("-",".",group$Sample)

#### caculate distance matrix of all samples
set.seed(123)
mag_bray <- vegdist(mag,method = "bray")
### anosim of samples of differnet trenches
anosim_result_dis <- anosim(mag_bray, group$Trench, permutations = 999)
summary(anosim_result_dis) #get R and p of anosim
###1. NMDS
###1.1 NMDS of Trench
nmds <- metaMDS(mag_bray, k = 2)
stress <- nmds$stress ### stress
nm_df <- as.data.frame(nmds$points)#get points
nm_df$Sample <- row.names(nm_df)  
nm_df1 <- merge(nm_df,group,by="Sample") # all sample points

nm_df1 <- nm_df1 %>%  
  mutate(Trench = case_when(  
    Trench == "Mariana" ~ "MT",  
    Trench == "Yap" ~ "YP",  
    Trench == "Philippines" ~ "PB")) 
nm_df1$Trench <- factor(nm_df1$Trench, levels = c("MT", "YP", "PB"))

color=c("#8DA0CB","#ED696C","#66C2A5")
p1<-ggplot(data=nm_df1,aes(MDS1, MDS2))+#
  theme_bw()+
  theme(panel.grid = element_blank()) +
  geom_point(aes(fill=Trench),size=2.5,color="NA",shape=21,alpha=0.7)+#
  labs(x=paste0("NMDS1 (Stress=0.155)"),
       y=paste0("NMDS2 "))+
  scale_fill_manual(values = color)+
  theme(axis.title.x=element_text(size=14,color="black"),#
        axis.title.y=element_text(size=14,angle=90,color="black"),#
        axis.text.y=element_text(size=14,color="black"),#x
        axis.text.x=element_text(size=14,color="black"),
        panel.border = element_rect(size = 1, color = "black"))
#panel.grid = element_blank()#the panel is white
print(p1)
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/beta_diversity/output/NMDS_Trench.tiff", 
       p1, width = 4, height = 3, dpi = 300)


### the MAG of Mariana Trench (MT)
mag_rowname <- data.frame(Sample = row.names(mag), mag)#change rowname to Sample

subMT_group <- group %>% 
  filter(Trench == "Mariana")
subMT_mag<-merge(subMT_group,mag_rowname,by="Sample")#merge group and mag of MT
row.names(subMT_mag) <- subMT_mag$Sample
### delect the group and get the table of MAG relative abundance
subMT_mag1<-subMT_mag[,-(1:15)]

### caculate distance matrix of MT samples
MT_mag_bray <- vegdist(subMT_mag1,method = "bray")
##### anosim of three regions of Mariana Trench
anosim_result_dis <- anosim(MT_mag_bray, subMT_group$TopographyRegion, permutations = 999)
summary(anosim_result_dis)

###1.2 NMDS of three regions of Mariana Trench
nmds_MT <- metaMDS(MT_mag_bray, k = 2)
stress1 <- nmds_MT$stress
nm_dfMT <- as.data.frame(nmds_MT$points)#get points
nm_dfMT$Sample <- row.names(nm_dfMT)  

nm_dfMT1 <- merge(nm_dfMT,group,by="Sample")
nm_dfMT1 <- nm_dfMT1 %>%  
  mutate(TopographyRegion = case_when(  
    TopographyRegion == "Mariana-Central-Axis" ~ "Bt",  
    TopographyRegion == "Mariana-Northern-Slope" ~ "NS",  
    TopographyRegion == "Mariana-Southern-Slope" ~ "SS"  ))  

color1=c("#4C98D9","#F48120","#ABD387")#color
p2<-ggplot(data=nm_dfMT1,aes(x=MDS1,y=MDS2))+#
  theme_bw()+
  theme(panel.grid = element_blank()) +
  geom_point(aes(fill=TopographyRegion),size=2.5,color="NA",shape=21,alpha=0.7)+#
  labs(x=paste0("NMDS1 (Stress=0.153)"),
       y=paste0("NMDS2"))+
  scale_fill_manual(values = color1)+
  theme(axis.title.x=element_text(size=14,color="black"),
        axis.title.y=element_text(size=14,angle=90,color="black"),#
        axis.text.y=element_text(size=14,color="black"),
        axis.text.x=element_text(size=14,color="black"),
        panel.border = element_rect(size = 1, color = "black"))
print(p2)
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/beta_diversity/output/NMDS_MT.tiff",
       p2, width = 4.8, height = 3, dpi = 300)

### 2 PCoA
### 2.1 PCoA of Trench
pcoa <- cmdscale (mag_bray,eig=TRUE)
pc12 <- pcoa$points[,1:2]
pc <- round(pcoa$eig/sum(pcoa$eig)*100,digits=2)
pc12 <- as.data.frame(pc12)
pc12$Sample <- row.names(pc12)
head(pc12)
eig = summary(eigenvals(pcoa))#over all
axis = paste0("PCoA", 1:ncol(eig))
eig = data.frame(Axis = axis, t(eig)[, -3])
#get pco1 and pco2 of all sample
pco1 = round(eig[1, 3] * 100, 2)
pco2 = round(eig[2, 3] * 100, 2)

pcoa_all <- merge(pc12,group,by="Sample")
pcoa_all <- pcoa_all %>%  
  mutate(Trench = case_when(  
    Trench == "Mariana" ~ "MT",  
    Trench == "Yap" ~ "YP",  
    Trench == "Philippines" ~ "PB")) 
pcoa_all$Trench <- factor(pcoa_all$Trench, levels = c("MT", "YP", "PB"))

color=c("#8DA0CB","#ED696C","#66C2A5")#new color

p3<-ggplot(data=pcoa_all,aes(x=V1,y=V2))+#
  theme_bw()+
  theme(panel.grid = element_blank()) +
  geom_point(aes(fill=Trench),size=2.5,color="NA",shape=21,alpha=0.7)+
  labs(x=paste0("PCo1 = 27.76%"),
       y=paste0("PCo2 = 15.55%"))+
  scale_fill_manual(values = color)+
  theme(axis.title.x=element_text(size=14,color="black"),#
        axis.title.y=element_text(size=14,angle=90,color="black"),#
        axis.text.y=element_text(size=14,color="black"),#x
        axis.text.x=element_text(size=14,color="black"),
        panel.border = element_rect(size = 1, color = "black"))
print(p3)
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/beta_diversity/output/pcoa_Trench.tiff", 
       p3, width = 4, height = 3, dpi = 300)

###Pcoa of MT
pcoaMT <- cmdscale (MT_mag_bray,eig=TRUE)
eigMT = summary(eigenvals(pcoaMT))
axisMT = paste0("PCoA", 1:ncol(eigMT))
#get pco1 and pco2 of MT
eigMT = data.frame(AxisMT = axisMT, t(eigMT)[, -3])
pco1MT = round(eigMT[1, 3] * 100, 2)
pco2MT = round(eigMT[2, 3] * 100, 2)
pc12MT <- pcoaMT$points[,1:2]
#pc <- round(pcoa$eig/sum(pcoa$eig)*100,digits=2)
pc12MT <- as.data.frame(pc12MT)
pc12MT$Sample <- row.names(pc12MT)
pcoa_MT <- merge(pc12MT,group,by="Sample")

pcoa_MT <- pcoa_MT %>%  
  mutate(TopographyRegion = case_when(  
    TopographyRegion == "Mariana-Central-Axis" ~ "Bt",  
    TopographyRegion == "Mariana-Northern-Slope" ~ "NS",  
    TopographyRegion == "Mariana-Southern-Slope" ~ "SS"  ))  
color1=c("#4C98D9","#F48120","#ABD387")#color

p4<-ggplot(data=pcoa_MT,aes(x=V1,y=V2))+#
  theme_bw()+
  theme(panel.grid = element_blank()) +
  geom_point(aes(fill=TopographyRegion),size=2.5,color="NA",shape=21,alpha=0.7)+#
  labs(x=paste0("PCo1 =21.17%"),
       y=paste0("PCo1 =17.93%"))+
  scale_fill_manual(values = color1)+
  theme(axis.title.x=element_text(size=14,color="black"),#
        axis.title.y=element_text(size=14,angle=90,color="black"),#
        axis.text.y=element_text(size=14,color="black"),#x
        axis.text.x=element_text(size=14,color="black"),
        panel.border = element_rect(size = 1, color = "black"))
print(p4)
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/beta_diversity/output/pcoa_MT.tiff",
       p4, width = 4.8, height = 3, dpi = 300)

