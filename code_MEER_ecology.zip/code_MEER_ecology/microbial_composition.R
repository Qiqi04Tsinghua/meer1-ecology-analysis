### Author Shanshan Huang & Dr. Qi Qi
###load the package and MAG, tax, group table 
library(dplyr)
library(ggplot2)
library(janitor) 
library(tibble)
library(reshape2)
rpkm<-read.delim("D:/1ASJ/MEER/MAGdataplota/Code_MEER/composition_phylum/data/meer_rv2.rpkm.tsv")
group<-read.delim("D:/1ASJ/MEER/MAGdataplota/Code_MEER/composition_phylum/data/meta_Sample.txt",
                  sep = "\t")
group1<-group[,-(2:12)]
group1$Sample<-gsub("-",".",group1$Sample)
tax_all<-read.delim("D:/1ASJ/MEER/MAGdataplota/Code_MEER/composition_phylum/data/alltax_filled.txt",
                    sep = "\t")
tax_all1<-tax_all[,c(1,3)]##keep the phylum
pha_all<-merge(rpkm,tax_all1,by="Genome")
pha_all<-pha_all[,-1]###delete Genome name

pha_allsum <- pha_all %>%
  group_by(Phylum) %>%
  summarise(across(everything(), sum, .names = "{.col}"))
phy_allsum <-pha_allsum %>%
  mutate(Sum = rowSums(across(where(is.numeric)))) %>%  #sum
  arrange(desc(Sum)) ###arrange the sum of phylum descending
write.csv(phy_allsum, file = 'D:/1ASJ/MEER/MAGdataplota/Code_MEER/composition_phylum/output/rpk_sumphy_de.csv', 
          quote = F, row.names = T) ###keep the table

#get top10 and the rest are Others
phy_allsum_top10 <- phy_allsum[1:10, -ncol(phy_allsum)] ## delete the sum
phy_allsum[, -1] <- sapply(phy_allsum[, -1], as.numeric)

###get others and sum
other_phyla <- tail(phy_allsum, 77) ###number 77 is the total phylun - 10 phylum
others_sum <- colSums(other_phyla[, -1])
### top 10 phylum and "Others"
phy_allsum_top10 <- rbind(phy_allsum_top10, c("Others", others_sum))         

### make the coloum sum = 100
phy_allsum_top10[, -1] <- sapply(phy_allsum_top10[, -1], as.numeric)
phy_allsum_top10[, -1]  <- data.frame(apply(phy_allsum_top10[, -1] ,2,function(x) x/sum(x)*100),
                                      stringsAsFactors = FALSE)
phy_allsum_top10 <- as.data.frame(phy_allsum_top10)
row.names(phy_allsum_top10)<-phy_allsum_top10$Phylum
phy_allsum_top10<-phy_allsum_top10[,-(1)]
###transfer the table
phy_allsum_top10_1<-as.data.frame(t(phy_allsum_top10))
phy_allsum_top10_1 <- phy_allsum_top10_1 %>%  
  rownames_to_column("Sample") 
### combine the phylum and group
combined_phy <- merge(phy_allsum_top10_1, group1, by = "Sample")  
### according to the Trench
mean_phy <- combined_phy %>%  
  select(-Sample) %>% # Sample  
  group_by(Trench) %>%  
  summarise_all(mean) # 
mean_phy<-mean_phy[,-c(13:14)]#delete the useful coloum
mean_phy1<-as.data.frame(t(mean_phy))
mean_phy11 <- row_to_names(mean_phy1, row_number = 1) 
mean_phy11$Yap <- as.numeric(mean_phy11$Yap)
mean_phy11$Mariana <- as.numeric(mean_phy11$Mariana)
mean_phy11$Philippines <- as.numeric(mean_phy11$Philippines)
###define the levels of phylum
mean_phy11$Taxonomy <- factor(rownames(mean_phy11), 
                              levels = rev(rownames(mean_phy11)))
mean_phy11 <- melt(mean_phy11, id = 'Taxonomy')
mean_phy11 <- mean_phy11 %>%  
  mutate(variable = case_when(  
    variable == "Mariana" ~ "MT",  
    variable == "Yap" ~ "YT",  
    variable == "Philippines" ~ "PB")) 
mean_phy11$variable <- factor(mean_phy11$variable, 
                              levels = c("PB", "YT", "MT")) 
#levels(mean_phy11$Taxonomy)
mean_phy11$Taxonomy <- factor(mean_phy11$Taxonomy, levels = 
                                c("Thermoproteota", "Pseudomonadota", "Chloroflexota","Planctomycetota",
                                  "Patescibacteria", "Nanoarchaeota", "Marinisomatota","Gemmatimonadota",
                                  "Bacteroidota","Acidobacteriota","Others"))

p <-ggplot(mean_phy11,aes(x=variable,y=value, fill = Taxonomy))+ 
  #geom_bar(,position = "fill") +
  geom_col(position = 'stack', width = 0.6) +
  labs(x = '', y = 'Relative Abundance(%)') +
  #theme(axis.text.x = element_text(angle = 0, hjust = 1))+
  theme(axis.text = element_text(size = 14,color = "black"),
        axis.title = element_text(size = 14,color = "black")) +
  theme(legend.text = element_text(size = 10,color = "black"))+
  scale_fill_manual(values =  rev(c('#BFBFBF','#FF7F02','#FCBF70', '#FA9A99','#B2DF8A',
                                    '#1F78B4','#A7CEE3','#CDBD93',  '#18BC9E', '#E31B1B', '#2C3E50')), 
                    guide=guide_legend(ncol=1)) +
  theme(panel.grid = element_blank(), 
        panel.background = element_rect(color = 'black',linewidth  = 1,fill = 'transparent')) +
  theme(legend.title = element_blank())  
#+scale_y_continuous(limits = c(0,100), breaks = seq(0,100,25)) 

p
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/composition_phylum/output/phylum_trench.tiff", 
       plot = p, width = 5, height = 3.2, dpi = 300)                     

### Within the Mariana Trench
combined_phy1<-subset(combined_phy, TopographyRegion != "Others")
mean_phymt <- combined_phy1 %>%  
  select(-Sample) %>% # Sample  
  group_by(TopographyRegion) %>%  
  summarise_all(mean) # 

mean_phymt<-mean_phymt[,-c(13:14)]
mean_phymt1<-as.data.frame(t(mean_phymt))

mean_phymt11 <- row_to_names(mean_phymt1, row_number = 1) 
mean_phymt11$'Mariana-Central-Axis'<- as.numeric(mean_phymt11$'Mariana-Central-Axis')
mean_phymt11$'Mariana-Northern-Slope'<- as.numeric(mean_phymt11$'Mariana-Northern-Slope')
mean_phymt11$'Mariana-Southern-Slope' <- as.numeric(mean_phymt11$'Mariana-Southern-Slope')
mean_phymt11 <- data.frame(apply(mean_phymt11,2,function(x) x/sum(x)*100),
                           stringsAsFactors = FALSE)
mean_phymt11$Taxonomy <- factor(rownames(mean_phymt11), 
                                levels = rev(rownames(mean_phymt11)))
mean_phymt11 <- melt(mean_phymt11, id = 'Taxonomy')
mean_phymt11  <- mean_phymt11  %>%  
  mutate(variable = case_when(  
    variable == "Mariana.Central.Axis" ~ "Bt",  
    variable == "Mariana.Northern.Slope" ~ "NS",  
    variable == "Mariana.Southern.Slope" ~ "SS"  ))#!sometime is . or - 
mean_phymt11 $variable <- factor(mean_phymt11 $variable, 
                                 levels = c("Bt", "NS", "SS")) 

#levels(mean_phymt11$Taxonomy)
mean_phymt11$Taxonomy <- factor(mean_phymt11$Taxonomy, levels = 
                                  c("Thermoproteota", "Pseudomonadota", "Chloroflexota","Planctomycetota",
                                    "Patescibacteria", "Nanoarchaeota", "Marinisomatota","Gemmatimonadota",
                                    "Bacteroidota","Acidobacteriota","Others"))

p <-ggplot(mean_phymt11,aes(x=variable,y=value, fill = Taxonomy))+ 
  geom_col(position = 'stack', width = 0.6) +
  labs(x = '', y = 'Relative Abundance(%)') +
  #theme(axis.text.x = element_text(angle = 0, hjust = 1))+
  theme(axis.text = element_text(size = 14,color = "black"),
        axis.title = element_text(size = 14,color = "black")) +
  theme(legend.text = element_text(size = 10,color = "black"))+
  scale_fill_manual(values =  rev(c('#BFBFBF','#FF7F02','#FCBF70', '#FA9A99','#B2DF8A',
                                    '#1F78B4','#A7CEE3','#CDBD93',  '#18BC9E', '#E31B1B', '#2C3E50')), 
                    guide=guide_legend(ncol=1)) +
  theme(panel.grid = element_blank(), 
        panel.background = element_rect(color = 'black',linewidth  = 1,fill = 'transparent')) +
  
  theme(legend.title = element_blank())  

p
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/composition_phylum/output/phylum_MT.tiff", 
       plot = p, width = 5, height = 3.2, dpi = 300)

### within MT layer0-30 flow plot
####### from line 99 combined_phy1
combined_mtlayphy1 <- combined_phy1 %>%  
  filter(Layer %in% c("0-2","2-4","4-6","6-8","8-10","10-12", "12-14","14-16",
                      "16-18","18-20","20-22","22-24","24-26","26-28","28-30"))

mean_mtlayphy <- combined_mtlayphy1 %>%  
  select(-Sample) %>% # Sample  
  group_by(Layer) %>%  
  summarise_all(mean) 
mean_mtlayphy<-mean_mtlayphy[,-c(13:14)]
# set the order of layer  
levels_order <- c("28-30", "26-28","24-26","22-24","20-22","18-20",
                  "16-18","14-16","12-14","10-12","8-10","6-8","4-6", "2-4","0-2")  
# reverse Layer to factor  
mean_mtlayphy$Layer <- factor(mean_mtlayphy$Layer,
                              levels = levels_order, ordered = TRUE)  
# reorder according to the levels_order
mean_mtlayphy1 <- mean_mtlayphy[order(mean_mtlayphy$Layer), ]  
#add the NO colum at the last
mean_mtlayphy1$NO <- 1:nrow(mean_mtlayphy1)
#change the data into plot needed
mean_mtlayphy11 <- melt(mean_mtlayphy1, id = c('NO', 'Layer'))
#plot
p1<- ggplot(mean_mtlayphy11, aes(x =  NO, y =value, fill = variable)) +
  geom_area(position = "stack") +
  scale_fill_manual(limits = c("Thermoproteota", "Pseudomonadota", "Chloroflexota","Planctomycetota",
                               "Patescibacteria", "Nanoarchaeota", "Marinisomatota","Gemmatimonadota",
                               "Bacteroidota","Acidobacteriota","Others"), 
                    values = c('#2C3E50', '#E31B1B', '#18BC9E', '#CDBD93', '#A7CEE3', 
                               '#1F78B4','#B2DF8A', '#FA9A99', '#FCBF70','#FF7F02','#BFBFBF')) +
  coord_flip() +  
  labs(y = 'Relative abundance(%)', x = '', fill = 'Taxonomy')+
  scale_x_continuous(breaks = unique(mean_mtlayphy11$NO), 
                     labels = unique(mean_mtlayphy11$Layer)) +
  #,expand = expansion(mult = c(0.05, 0.05))) 
  theme(panel.grid = element_blank(), 
        panel.background = element_rect(color = 'black',fill = 'white',size = 0.1), 
        panel.border = element_rect(color = 'black', fill = NA, size = 0.5),
        axis.ticks = element_line(color = 'black', size = 0.5), 
        axis.text.x = element_text(color = 'black', size = 12), 
        axis.text.y = element_text(color = 'black', size = 12), 
        axis.title.y = element_text(color = 'black', size = 12),
        legend.text = element_text(color = 'black', size = 10), 
        legend.title = element_text(color = 'black', size = 12)) 
print(p1)
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/composition_phylum//output/phy_MT_layer.tiff", 
       plot = p1, width = 4.9, height = 2.8, dpi = 300)
