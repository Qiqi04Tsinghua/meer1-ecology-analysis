#############Author Shanshan Huang & Dr. Qi Qi
##############Violin plot of Shannon diversity 
library(vegan)
library(picante)
library(ggplot2)
library(ggsignif)
library(dplyr)
library(rstatix) 
shan_rpk<-read.csv("D:/1ASJ/MEER/MAGdataplota/Code_MEER/alpha_diversity/data/shannon.csv")
group<-read.table("D:/1ASJ/MEER/MAGdataplota/Code_MEER/alpha_diversity/data/meta_Sample.txt",
                  sep='\t', header=T,check.names=FALSE )
group$Sample<-gsub("-",".",group$Sample)
all_shannon<-merge(group,shan_rpk,by="Sample")

######test of different trench
all_shannon1<-all_shannon[,-c(2:12)]
kruskal.test(shannon_index ~ Trench, data = all_shannon1)
test_tren <- all_shannon1 %>%
  wilcox_test(shannon_index ~ Trench, p.adjust.method = "bonferroni")

all_shannon1 <- all_shannon1 %>%  
  mutate(Trench = case_when(  
    Trench == "Mariana" ~ "MT",  
    Trench == "Yap" ~ "YT",  
    Trench == "Philippines" ~ "PB")) 
all_shannon1$Trench <- factor(all_shannon1$Trench, levels = c("PB", "YT", "MT")) 
col=c("PB"="#66C2A5","YT"="#ED696C","MT"= "#8DA0CB")

############# violin plot
p1 <- ggplot(all_shannon1,aes(x=Trench,y=shannon_index))+
  geom_point(aes(color = Trench), position = 'jitter',
             size = 1,alpha = 0.7) +
  scale_color_manual(values = col) +
  geom_violin(aes(color = Trench),  # 
              fill = NA,scale = 'width',linewidth = 0.8, # 
              trim = TRUE, alpha = 0.7)+
  xlab("") +      
  ylab("Shannon diversity") + 
  theme_bw()+ #
  theme(    
    axis.title.x=element_text(size=14),#
    axis.title.y=element_text(size=14,angle=90),#
    axis.text.y=element_text(size=14,color="black"),#x
    axis.text.x=element_text(size=14,color="black"),
    panel.grid = element_blank(),  # 
    panel.border = element_rect(colour = "black", size = 1),
    panel.background = element_rect(fill = "white", colour = NA))+
  scale_y_continuous(limits = c(0,9.2), breaks = seq(0,9.2,2)) +
  geom_signif(comparisons=list(c("PB","YT"),  
                               c("PB","MT"),  
                               c("YT","MT")),  
              y_position = c(7.3,7.9,8.5),  
              tip_length = 0, vjust=0.2,  
              annotation= c("***", "***", "***")) +  
  stat_summary(fun = mean, geom = "point", shape = 9, size = 4, stroke = 1, 
               fill = NA, aes(color = Trench)) 
p1
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/alpha_diversity/output/shannon_violin_trench.tiff", 
       plot = p1, width = 3.8, height = 3, dpi = 300)


############### three regins of MT
all_shannon_mt <- all_shannon1 %>%  
  filter(TopographyRegion %in% c("Mariana-Central-Axis",
                                 "Mariana-Northern-Slope","Mariana-Southern-Slope")) 
####test of regions within MT
kruskal.test(shannon_index ~ TopographyRegion, data = all_shannon_mt )
test_mt <- all_shannon_mt %>%
  wilcox_test(shannon_index ~ TopographyRegion, p.adjust.method = "bonferroni")

all_shannon_mt  <-all_shannon_mt %>%  
  mutate(TopographyRegion = case_when(  
    TopographyRegion == "Mariana-Central-Axis" ~ "Bt",  
    TopographyRegion == "Mariana-Northern-Slope" ~ "NS",  
    TopographyRegion == "Mariana-Southern-Slope" ~ "SS"  )) 
all_shannon_mt$TopographyRegion <- factor(all_shannon_mt$TopographyRegion, 
                                          levels = c("Bt", "NS", "SS")) 
colnames(all_shannon_mt)[colnames(all_shannon_mt) == "TopographyRegion"] <- "Topore"
col1 <-c ("Bt"="#4C98D9","NS"="#F48120","SS"="#ABD387")

################# violin plot
p1 <- ggplot(all_shannon_mt,aes(x=Topore,y=shannon_index))+
  geom_point(aes(color = Topore), position = 'jitter',
             size = 1,alpha = 0.7) +
  scale_color_manual(values = col1) +
  geom_violin(aes(color = Topore),  # 
              fill = NA,scale = 'width',linewidth = 0.8, # 
              trim = TRUE, alpha = 0.7)+  
  stat_summary(fun = mean, geom = "point", shape = 9, 
               size = 4, fill = NA, color = col1)+
  xlab("") +      
  ylab("Shannon diversity") + 
  theme_bw()+ #
  theme(    
    axis.title.x=element_text(size=14),#
    axis.title.y=element_text(size=14,angle=90),#
    axis.text.y=element_text(size=14,color="black"),#x
    axis.text.x=element_text(size=14,color="black"),
    panel.grid = element_blank(),  # 
    panel.border = element_rect(colour = "black", size = 1),
    panel.background = element_rect(fill = "white", colour = NA))+
  scale_y_continuous(limits = c(0,9), breaks = seq(0,9,2)) +
  geom_signif(comparisons=list(#c("Bt","NS"),  
    c("Bt","SS"),  
    c("NS","SS")),  
    y_position = c(7.4,8),  
    tip_length = 0, vjust=0.2,  
    annotation= c("***", "***"))
p1
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/alpha_diversity/output/shannon_violin_mt.tiff", 
       plot = p1, width = 3.8, height = 3, dpi = 300)

### Double Y-axis polyline
# Shannon and Phylogenetic diversity of Mariana Trench along sediment depth
shannon_layer<-read.csv("D:/1ASJ/MEER/MAGdataplota/Code_MEER/alpha_diversity/data/summary_layerS.csv",
                        row.names = 1)
shannon_layer$group <- "shannon"

pd_layer<-read.csv("D:/1ASJ/MEER/MAGdataplota/Code_MEER/alpha_diversity/data/summary_layerP.csv",
                   row.names = 1)
pd_layer$group <- "pd"
library(dplyr)
layer_all <- bind_rows(pd_layer, shannon_layer)
layer_all$Layer <- factor(layer_all$Layer, levels = c("0-2","2-4","4-6",
                                                      "6-8","8-10","10-12", "12-14","14-16",
                                                      "16-18","18-20","20-22","22-24","24-26","26-28","28-30")) 
library(ggplot2)
p1 <- ggplot(layer_all[layer_all$group == "pd",], aes(x = Layer, y = mean, colour = group)) +    
  geom_line(aes(group = 1), size = 1) +  
  geom_point(aes(group = 1), size = 2) +  
  geom_errorbar(aes(ymin = mean - se, ymax = mean + se, group = 1),   
                width = 0.25, size = 0.5) +  
  theme_bw() +  
  labs(x = "Sediment depth (cm)", y = "Phylogenetic diversity") +    
  theme(panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(),  
        axis.text = element_text(colour = 'black', size = 10),  
        axis.text.x = element_text(angle = 90, hjust = 0.5, vjust = 0.5),
        axis.text.y = element_text(color = "red", size = 10,angle = 90),  #  Y 
        axis.title.y = element_text(color = "red", hjust = 0.5, size = 12,angle = 90)
  ) +  
  scale_colour_manual(values = c("pd" = "red")) +
  scale_y_continuous(limits = c(0, 500), sec.axis = sec_axis(~ . / 72, name = "Shannon diversity")) 
p1
# 
p2 <- p1 + 
  geom_line(data = layer_all[layer_all$group == "shannon",],
            aes(x = Layer, y = mean * 72, group = 1, colour = group), size = 1) +  
  geom_point(data = layer_all[layer_all$group == "shannon",],
             aes(x = Layer, y = mean * 72, group = 1, colour = group), size = 2) +  
  geom_errorbar(data = layer_all[layer_all$group == "shannon",], 
                aes(x = Layer, ymin = (mean - se) * 72, ymax = (mean + se) * 72, group = 1, colour = group),   
                width = 0.25, size = 0.5) +  
  #scale_y_continuous(sec.axis = sec_axis(~ . / 72, name = "Shannon diversity")) + 
  theme(
    axis.text.y.right = element_text(color = "blue",angle = 90, size = 12),  
    axis.title.y.right = element_text(color = "blue",angle = 90, size = 12) 
  ) +
  
  scale_colour_manual(values = c("pd" = "red", "shannon" = "blue")) + 
  labs(y = "Phylogenetic diversity")
p2
ggsave("D:/1ASJ/MEER/MAGdataplota/Code_MEER/alpha_diversity/output/alpha_MT.tiff", 
       plot = p2, width = 4.3, height = 2.9, dpi = 300)





